# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "save-incremental-backup",
    "author" : "lingtalfi", 
    "description" : "Saves an incremental backup",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "General" 
}


import bpy
import bpy.utils.previews
import re


addon_keymaps = {}
_icons = None


def sna_add_to_topbar_mt_editor_menus_54F96(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.sibop_a30d0', text='Save Incremental Backup', icon_value=0, emboss=True, depress=False)


class SNA_OT_Sibop_A30D0(bpy.types.Operator):
    bl_idname = "sna.sibop_a30d0"
    bl_label = "SIBOP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os

        def save_incremental_copy(use_backup_folder=True):
            current_filepath = bpy.data.filepath
            if not current_filepath:
                bpy.ops.wm.save_mainfile('INVOKE_DEFAULT')
                return
            directory, filename = os.path.split(current_filepath)
            basename, ext = os.path.splitext(filename)
            if use_backup_folder:
                # Updated backup folder structure to "incremental-backups/$"
                backup_folder = os.path.join(directory, "incremental-backups", basename)
                if not os.path.exists(backup_folder):
                    os.makedirs(backup_folder)
                save_directory = backup_folder
            else:
                save_directory = directory
            # List existing files in the save directory
            existing_files = os.listdir(save_directory)
            # Pattern to match files like "filename.001.blend"
            pattern = re.compile(rf"{re.escape(basename)}\.(\d+){re.escape(ext)}")
            # Find all version numbers in the existing files
            version_numbers = [int(match.group(1)) for file in existing_files if (match := pattern.match(file))]
            # Determine the next version number
            next_version = max(version_numbers) + 1 if version_numbers else 1
            # Construct the new filename with incremented number
            new_filename = f"{basename}.{next_version:03d}{ext}"
            new_filepath = os.path.join(save_directory, new_filename)
            # Save the incremental copy
            bpy.ops.wm.save_as_mainfile(filepath=new_filepath, copy=True)
            # Debug output to the console
            print(f"Saved incremental copy as: {new_filepath}")
            # Display a non-obtrusive popup message
            bpy.context.window_manager.popup_menu(
                lambda self, context: self.layout.label(text=f"Saved backup as: {new_filepath}"),
                title="Incremental Backup",
                icon='FILE_TICK'
            )
        save_incremental_copy(use_backup_folder=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.TOPBAR_MT_editor_menus.append(sna_add_to_topbar_mt_editor_menus_54F96)
    bpy.utils.register_class(SNA_OT_Sibop_A30D0)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.types.TOPBAR_MT_editor_menus.remove(sna_add_to_topbar_mt_editor_menus_54F96)
    bpy.utils.unregister_class(SNA_OT_Sibop_A30D0)
